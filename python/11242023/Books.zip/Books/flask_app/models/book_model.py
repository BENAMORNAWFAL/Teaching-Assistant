from ..config.mysqlconnection import connectToMySQL

class Book:
    def __init__(self, data):
        self.id = data['id']
        self.title = data['title']
        self.author_id = data['author_id']
        self.num_of_pages = data['num_of_pages']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM books;"
        books = []
        results = connectToMySQL('books_py_db').query_db(query)
        for row in results:
            books.append(cls(row))
        return books
    
    @classmethod
    def save(cls,data):
        query = "INSERT INTO books (title,num_of_pages,author_id) VALUES (%(title)s,%(num_of_pages)s,%(author_id)s);"
        return connectToMySQL('books_py_db').query_db(query,data)

    @classmethod
    def get_by_id(cls,data):
        query = "SELECT * FROM books WHERE books.id = %(id)s;"
        result = connectToMySQL('books_py_db').query_db(query,data)
        return cls(result[0])
    
    @classmethod
    def get_by_author_id(cls,data):
        query = "SELECT * FROM books WHERE author_id = %(id)s;"
        books = []
        results = connectToMySQL('books_py_db').query_db(query,data)
        for row in results:
            books.append(cls(row))
        return books

    @classmethod
    def update(cls, data):
        query = """
        UPDATE books SET title = %(title)s, num_of_pages = %(num_of_pages)s
        WHERE id = %(id)s;
        """
        return connectToMySQL("books_py_db").query_db(query,data)