from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DATABASE

class Pokemon:
    def __init__(self,data):
        self.id=data['id']
        self.name=data['name']
        self.type=data['type']
        self.power=data['power']
        self.hp=data['hp']
        self.image=data['image']
        self.user_id=data['user_id']
        self.created_at=data['created_at']
        self.updated_at=data['updated_at']

    @classmethod
    def createPokemon(cls,data):
        query="""
            INSERT INTO pokemons (name, type , power, hp , image ,user_id)
            """
        return connectToMySQL(DATABASE).query_db(query,data)