from flask_app import app
from flask import render_template,redirect, request , session





#===============render route ===========
@app.route('/pokemon/create')
def create():
    return render_template('create.html')

#==============Action route ==============
@app.route('/create/pokemon', methods=['POST'])
def createPokemon():
    data={
        **request.form,
        'user_id':session['user_id']
    }
    return redirect('/dashboard')